<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GenioModel extends Model
{
    //
}
