<!DOCTYPE html>
<html>
    <head>
        <title>SIG - Homens mais Inteligentes da História</title>
    </head>
    <body>
        <h3>Seja Bem-vindo, <br/>{{ $dados['nome'] }} </h3>
        <br/>
        <b>Sua senha é: {{ $dados['senha'] }}</b>
        <br/>
        <h4>{{ $dados['conteudo'] }}</h4>
        <br/>
        <img src="http://www.gileduardo.com.br/downloads/ass.png">
    </body>
</html>
