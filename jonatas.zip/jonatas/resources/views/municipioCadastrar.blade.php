@extends('principal')

@section('cabecalho')
    <div>
        <a href="/gestor">
            <img src=" {{ url('/img/municipio_ico.png') }}" style="height: 50px" >
        </a>
        &nbsp;Cadastrar Novo Municipio
    </div>
@endsection

@section('conteudo')
    <form action="{{ action('MunicipioController@salvar', 0) }}" method="POST" class="form">
        <input type="hidden" name="_token" value="{{{ csrf_token() }}}">
        <input type="hidden" name="cadastrar" value="C">

        <div class="row">
            <div class="col-sm-6">
                <label>Nome: </label>
                <input required type="text" name="nome" class="form-control">
            </div>
            <div class="col-sm-6">
                <label>Gestor: </label>
                <select required name="id_gestor" class="form-control">
                    <option disabled="true" selected="true"> </option>
                        @foreach ($gestores as $dados)
                            <option> {{ $dados->id }} - {{ $dados->nome }}</option>
                        @endforeach
                </select>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-sm-4">
                <label>Nrº Habitantes: </label>
                <input required type="number" name="nr_habitantes" class="form-control">
            </div>
            <div class="col-sm-4">
                <label>Área Total (Km²): </label>
                <input required type="number" name="area" class="form-control">
            </div>
            <div class="col-sm-4">
                <label>Porte: </label>
                <select required name="id_porte" class="form-control">
                    <option disabled="true" selected="true"> </option>
                        @foreach ($portes as $dados)
                            <option> {{ $dados->id }} - {{ $dados->descricao }}</option>
                        @endforeach
                </select>
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-success btn-block" ><b>Salvar</b></button>
    </form>
@endsection