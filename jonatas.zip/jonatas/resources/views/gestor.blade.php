@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/gestor_ico.png') }}" style="height: 50px" >
        &nbsp;Gestores Cadastrados
</div>
@stop

@section('conteudo')
    @if (old('cadastrar'))
        <div class="alert alert-success">
            <strong> {{ old('nome') }} </strong>: Cadastrado com Sucesso!
        </div>
    @endif

    @if (old('editar'))
        <div class="alert alert-success">
            <strong> {{ old('nome') }} </strong>: Alterado com Sucesso!
        </div>
    @endif


    <a href="{{ action('GestorController@cadastrar') }}"
       type="button" class="btn btn-primary btn-block" ><b>Cadastrar Gestor</b></a>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">NOME DO GESTOR</th>
                <th scope="col">DATA DE NASCIMENTO</th>
                <th scope="col">EVENTOS</th>
            </tr>
        </thead>
        <tbody>
            @foreach($gestores as $dados)
                <tr>
                    <th scope="row">{{ $dados->id }}</th>
                    <td>{{ $dados->nome }}</td>
                    <td>{{ $dados->nascimento }}</td>
                    <td>
                        <a href="{{ action('GestorController@editar', $dados->id) }}"><span class='glyphicon glyphicon-pencil'></span></a>
                        &nbsp;
                        <a href="{{ action('GestorController@remover', $dados->id) }}"><span class='glyphicon glyphicon-remove'></span></a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@stop
