<?php

namespace App\Http\Controllers;

use Request;
use App\Municipio;
use App\Gestor;
use App\Porte;
?>

@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/municipio_ico.png') }}" style="height: 50px" >
        &nbsp;Municipios Cadastrados
</div>
@stop

@section('conteudo')
    @if (old('cadastrar'))
        <div class="alert alert-success">
            <strong> {{ old('nome') }} </strong>: Cadastrado com Sucesso!
        </div>
    @endif

    @if (old('editar'))
        <div class="alert alert-success">
            <strong> {{ old('nome') }} </strong>: Alterado com Sucesso!
        </div>
    @endif


    <a href="{{ action('MunicipioController@cadastrar') }}"
       type="button" class="btn btn-primary btn-block" ><b>Cadastrar Municipio</b></a>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">NOME</th>
                <th scope="col">GESTOR</th>
                <th scope="col">NUMERO HABITANTES</th>
                <th scope="col">AREA TOTAL</th>
                <th scope="col">PORTE</th>
                <th scope="col">EVENTOS</th>
            </tr>
        </thead>
        <tbody>
            @foreach($municipios as $dados)
                <tr>
                    <th scope="row">{{ $dados->id }}</th>
                    <td>{{ $dados->nome }}</td>
                    <td>{{ Gestor::find($dados->id_gestor)->nome }}</td>
                    <td>{{ $dados->nr_habitantes }}</td>
                    <td>{{ $dados->area }}</td>
                    <td>{{ Porte::find($dados->id_porte)->descricao }}</td>
                    <td>
                        <a href="{{ action('MunicipioController@listar', $dados->id) }}"><span class='glyphicon glyphicon-pencil'></span></a>
                        &nbsp;
                        <a href="{{ action('MunicipioController@listar', $dados->id) }}"><span class='glyphicon glyphicon-remove'></span></a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@stop
