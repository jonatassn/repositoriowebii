@extends('principal')

@section('cabecalho')
    <div>
        <a href="/aluno">
            <img src=" {{ url('/img/gestor_ico.png') }}" style="height: 50px" >
        </a>
        &nbsp;Atualizar Dados do Gestor
    </div>
@endsection

@section('conteudo')
    <form action="{{ action('GestorController@salvar', $gestor->id) }}" method="POST" class="form">
        <input type="hidden" name="_token" value="{{{ csrf_token() }}}">
        <input type="hidden" name="editar" value="E">

        <div class="row">
            <div class="col-sm-6">
                <label>Nome: </label>
            <input required type="text" name="nome" class="form-control" value="{{ $gestor->nome }}" >
            </div>
            <div class="col-sm-6">
                <label>Data de Nascimento: </label>
            <input required type="date" name="nascimento" class="form-control" value="{{ $gestor->nascimento }}">
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-success btn-block" ><b>Salvar</b></button>
    </form>
@endsection
