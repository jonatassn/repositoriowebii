@extends('principal')

@section('cabecalho')
    <div>
        <a href="/gestor">
            <img src=" {{ url('/img/gestor_ico.png') }}" style="height: 50px" >
        </a>
        &nbsp;Cadastrar Novo Gestor
    </div>
@endsection

@section('conteudo')
    <form action="{{ action('GestorController@salvar', 0) }}" method="POST" class="form">
        <input type="hidden" name="_token" value="{{{ csrf_token() }}}">
        <input type="hidden" name="cadastrar" value="C">

        <div class="row">
            <div class="col-sm-6">
                <label>Nome: </label>
                <input required type="text" name="nome" class="form-control">
            </div>
            <div class="col-sm-6">
                <label>Data de Nascimento: </label>
                <input required type="date" name="nascimento" class="form-control">
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-success btn-block" ><b>Salvar</b></button>
    </form>
@endsection