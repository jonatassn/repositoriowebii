<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gestor extends Model
{
    //
    public $timestamps = false;
}
