<?php

namespace App\Http\Controllers;

use Request;
use App\Municipio;
use App\Gestor;
use App\Porte;

class MunicipioController extends Controller
{
    //
    public function listar() {
        $municipios = Municipio::all();
        return view('municipio')->with('municipios', $municipios);
    }

    
    public function cadastrar() {
        
        $gestores = Gestor::all();
        $portes = Porte::all();
        return view('municipioCadastrar')->with('gestores', $gestores)->with('portes', $portes);
    }
    
    public function salvar($id) {
        if($id == 0) {

            $objMunicipio = new Municipio();
            $objMunicipio->nome = mb_strtoupper(Request::input('nome'));
            $arr = explode(" ", Request::input('id_gestor'));
            $objMunicipio->id_gestor = $arr[0];
            $objMunicipio->nr_habitantes = Request::input('nr_habitantes');
            $objMunicipio->area = Request::input('area');
            $arr = explode(" ", Request::input('id_porte'));
            $objMunicipio->id_porte = $arr[0];
            $objMunicipio->save();
        }
        else {
            $objMunicipio = Municipio::find($id);
            $objMunicipio->nome = mb_strtoupper(Request::input('nome'));
            $arr = explode(" ", Request::input('id_gestor'));
            $objMunicipio->id_gestor = $arr[0];
            $objMunicipio->nr_habitantes = Request::input('nr_habitantes');
            $objMunicipio->area = Request::input('area');
            $arr = explode(" ", Request::input('id_porte'));
            $objMunicipio->id_porte = $arr[0];
            $objMunicipio->save();
        }

        return redirect()->action('MunicipioController@listar')->withInput();
    }
    /*
    public function remover($id) {
        $gestor = Gestor::find($id);

        if(empty($gestor)) {
            $msg = "<h2>[ERRO]: Gestor não encontrado para o ID=".$id."!</h2>";
            return view()->with('tipo', 'alert alert-warning')
                ->with('titulo', 'OPERAÇÂO INVÁLIDA')
                ->with('msg', $msg)
                ->with('acao', '/gestor');
        }

        return view('gestorRemover')->with('gestor', $gestor);
    }

    public function confirmar($id) {
        $objGestor = Gestor::find($id);
        $objGestor->delete();

        return redirect()->action('GestorController@listar')->withInput();
    }

    public function editar($id) {
        $gestor = Gestor::find($id);
        return view('gestorEditar')->with('gestor', $gestor);
    }
    */
}
