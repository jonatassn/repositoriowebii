<?php

namespace App\Http\Controllers;

use Request;
use App\Gestor;

class GestorController extends Controller
{
    public function listar() {
        $gestores = Gestor::all();
        return view('gestor')->with('gestores', $gestores);
    }

    public function cadastrar() {
        return view('gestorCadastrar');
    }

    public function salvar($id) {
        if($id == 0) {
            $objGestor = new Gestor();
            $objGestor->nome = mb_strtoupper(Request::input('nome'));
            $objGestor->nascimento = Request::input('nascimento');
            $objGestor->save();
        }
        else {
            $objGestor = Gestor::find($id);
            $objGestor->nome = mb_strtoupper(Request::input('nome'));
            $objGestor->nascimento = Request::input('nascimento');
            $objGestor->save();
        }

        return redirect()->action('GestorController@listar')->withInput();
    }

    public function remover($id) {
        $gestor = Gestor::find($id);

        if(empty($gestor)) {
            $msg = "<h2>[ERRO]: Gestor não encontrado para o ID=".$id."!</h2>";
            return view()->with('tipo', 'alert alert-warning')
                ->with('titulo', 'OPERAÇÂO INVÁLIDA')
                ->with('msg', $msg)
                ->with('acao', '/gestor');
        }

        return view('gestorRemover')->with('gestor', $gestor);
    }

    public function confirmar($id) {
        $objGestor = Gestor::find($id);
        $objGestor->delete();

        return redirect()->action('GestorController@listar')->withInput();
    }

    public function editar($id) {
        $gestor = Gestor::find($id);
        return view('gestorEditar')->with('gestor', $gestor);
    }
}
