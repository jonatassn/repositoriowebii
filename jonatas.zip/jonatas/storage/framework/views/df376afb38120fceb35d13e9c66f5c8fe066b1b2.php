<?php $__env->startSection('cabecalho'); ?>
    <div>
        <a href="/aluno">
            <img src=" <?php echo e(url('/img/gestor_ico.png')); ?>" style="height: 50px" >
        </a>
        &nbsp;Atualizar Dados do Gestor
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <form action="<?php echo e(action('GestorController@salvar', $gestor->id)); ?>" method="POST" class="form">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" name="editar" value="E">

        <div class="row">
            <div class="col-sm-6">
                <label>Nome: </label>
            <input required type="text" name="nome" class="form-control" value="<?php echo e($gestor->nome); ?>" >
            </div>
            <div class="col-sm-6">
                <label>Data de Nascimento: </label>
            <input required type="date" name="nascimento" class="form-control" value="<?php echo e($gestor->nascimento); ?>">
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-success btn-block" ><b>Salvar</b></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aluno/prova web ii/jonatas/resources/views/gestorEditar.blade.php ENDPATH**/ ?>