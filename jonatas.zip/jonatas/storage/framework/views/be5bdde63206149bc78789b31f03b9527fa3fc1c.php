<?php $__env->startSection('cabecalho'); ?>
<div id="m_texto">
        <img src=" <?php echo e(url('/img/gestor_ico.png')); ?>" style="height: 50px" >
        &nbsp;Gestores Cadastrados
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <?php if(old('cadastrar')): ?>
        <div class="alert alert-success">
            <strong> <?php echo e(old('nome')); ?> </strong>: Cadastrado com Sucesso!
        </div>
    <?php endif; ?>

    <?php if(old('editar')): ?>
        <div class="alert alert-success">
            <strong> <?php echo e(old('nome')); ?> </strong>: Alterado com Sucesso!
        </div>
    <?php endif; ?>


    <a href="<?php echo e(action('GestorController@cadastrar')); ?>"
       type="button" class="btn btn-primary btn-block" ><b>Cadastrar Gestor</b></a>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">NOME DO GESTOR</th>
                <th scope="col">DATA DE NASCIMENTO</th>
                <th scope="col">EVENTOS</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $gestores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($dados->id); ?></th>
                    <td><?php echo e($dados->nome); ?></td>
                    <td><?php echo e($dados->nascimento); ?></td>
                    <td>
                        <a href="<?php echo e(action('GestorController@editar', $dados->id)); ?>"><span class='glyphicon glyphicon-pencil'></span></a>
                        &nbsp;
                        <a href="<?php echo e(action('GestorController@remover', $dados->id)); ?>"><span class='glyphicon glyphicon-remove'></span></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aluno/prova web ii/jonatas/resources/views/gestor.blade.php ENDPATH**/ ?>