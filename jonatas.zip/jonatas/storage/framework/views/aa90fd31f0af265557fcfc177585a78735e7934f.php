<?php $__env->startSection('cabecalho'); ?>
    <img src="<?php echo e(url('/img/homep_ico.png')); ?>">
    &nbsp;Menu Principal    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<div class='row'>

    <div class='col-sm-3' style="text-align: center">
        <a href="/gestor">
            <img src="<?php echo e(url('/img/gestor_ico.png')); ?>">
        </a>
        <h3> Gestor </h3>
    </div>

    <div class='col-sm-3' style="text-align: center">
        <a href="/municipio">
            <img src="<?php echo e(url('/img/municipio_ico.png')); ?>">
        </a>
        <h3> Municipio </h3>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aluno/prova web ii/jonatas/resources/views/main.blade.php ENDPATH**/ ?>