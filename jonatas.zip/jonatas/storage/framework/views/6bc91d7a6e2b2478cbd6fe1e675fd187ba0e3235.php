<?php $__env->startSection('script'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <h3> Deseja remover o gestor? <br><br><b><?php echo e($gestor->nome); ?></b></h3>
            </div>
            <div class="modal-footer">
                <a href="<?php echo e(action('GestorController@confirmar', $gestor->id)); ?>" type="button" class="btn btn-success">Sim</a>
                <a href="<?php echo e(action('GestorController@listar')); ?>" type="button" class="btn btn-danger">Não</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aluno/prova web ii/jonatas/resources/views/gestorRemover.blade.php ENDPATH**/ ?>