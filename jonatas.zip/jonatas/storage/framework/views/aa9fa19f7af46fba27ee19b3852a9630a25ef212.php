<?php

namespace App\Http\Controllers;

use Request;
use App\Municipio;
use App\Gestor;
use App\Porte;
?>



<?php $__env->startSection('cabecalho'); ?>
<div id="m_texto">
        <img src=" <?php echo e(url('/img/municipio_ico.png')); ?>" style="height: 50px" >
        &nbsp;Municipios Cadastrados
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <?php if(old('cadastrar')): ?>
        <div class="alert alert-success">
            <strong> <?php echo e(old('nome')); ?> </strong>: Cadastrado com Sucesso!
        </div>
    <?php endif; ?>

    <?php if(old('editar')): ?>
        <div class="alert alert-success">
            <strong> <?php echo e(old('nome')); ?> </strong>: Alterado com Sucesso!
        </div>
    <?php endif; ?>


    <a href="<?php echo e(action('MunicipioController@cadastrar')); ?>"
       type="button" class="btn btn-primary btn-block" ><b>Cadastrar Municipio</b></a>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">NOME</th>
                <th scope="col">GESTOR</th>
                <th scope="col">NUMERO HABITANTES</th>
                <th scope="col">AREA TOTAL</th>
                <th scope="col">PORTE</th>
                <th scope="col">EVENTOS</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($dados->id); ?></th>
                    <td><?php echo e($dados->nome); ?></td>
                    <td><?php echo e(Gestor::find($dados->id_gestor)->nome); ?></td>
                    <td><?php echo e($dados->nr_habitantes); ?></td>
                    <td><?php echo e($dados->area); ?></td>
                    <td><?php echo e(Porte::find($dados->id_porte)->descricao); ?></td>
                    <td>
                        <a href="<?php echo e(action('MunicipioController@listar', $dados->id)); ?>"><span class='glyphicon glyphicon-pencil'></span></a>
                        &nbsp;
                        <a href="<?php echo e(action('MunicipioController@listar', $dados->id)); ?>"><span class='glyphicon glyphicon-remove'></span></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aluno/prova web ii/jonatas/resources/views/municipio.blade.php ENDPATH**/ ?>