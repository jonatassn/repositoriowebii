<?php $__env->startSection('cabecalho'); ?>
    <div>
        <a href="/gestor">
            <img src=" <?php echo e(url('/img/municipio_ico.png')); ?>" style="height: 50px" >
        </a>
        &nbsp;Cadastrar Novo Municipio
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <form action="<?php echo e(action('MunicipioController@salvar', 0)); ?>" method="POST" class="form">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" name="cadastrar" value="C">

        <div class="row">
            <div class="col-sm-6">
                <label>Nome: </label>
                <input required type="text" name="nome" class="form-control">
            </div>
            <div class="col-sm-6">
                <label>Gestor: </label>
                <select required name="id_gestor" class="form-control">
                    <option disabled="true" selected="true"> </option>
                        <?php $__currentLoopData = $gestores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option> <?php echo e($dados->id); ?> - <?php echo e($dados->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-sm-4">
                <label>Nrº Habitantes: </label>
                <input required type="number" name="nr_habitantes" class="form-control">
            </div>
            <div class="col-sm-4">
                <label>Área Total (Km²): </label>
                <input required type="number" name="area" class="form-control">
            </div>
            <div class="col-sm-4">
                <label>Porte: </label>
                <select required name="id_porte" class="form-control">
                    <option disabled="true" selected="true"> </option>
                        <?php $__currentLoopData = $portes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option> <?php echo e($dados->id); ?> - <?php echo e($dados->descricao); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-success btn-block" ><b>Salvar</b></button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aluno/prova web ii/jonatas/resources/views/municipioCadastrar.blade.php ENDPATH**/ ?>