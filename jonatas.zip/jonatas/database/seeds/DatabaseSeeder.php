<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        DB::insert('insert into portes (descricao) values (?)', 
            array('Pequeno'));
        DB::insert('insert into portes (descricao) values (?)', 
            array('Médio'));
        DB::insert('insert into portes (descricao) values (?)', 
            array('Grande'));
    }
}
