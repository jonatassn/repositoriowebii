<?php

	require 'Slim/Slim.php';
	\Slim\Slim::registerAutoloader();

	$app = new \Slim\Slim();

	$app->get('/', function() {
		echo "<h1>(Slim) Web Service Funcionando!</h1>";
	});

	$app->get('/', function($dados) {
		echo "<h2>[GET] - Framework Slim</h2>";
	});

	$app->post('/', function() use ($app) {
		echo "<h2>[POST] - Framework Slim</h2>";
	});


	$app->put('/', function() use ($app) {
		echo "<h2>[PUT] Framework Slim</h2>";
	});


	$app->delete('/', function() use ($app){
		echo "<h2>[DELETE] Framework Slim</h2>";
	});

	$app->run();

?>
