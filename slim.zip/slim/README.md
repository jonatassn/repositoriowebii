# slimexemplo
Exemplo de um Web Service REST desenvolvido com PHP SLIM FRAMEWORK
